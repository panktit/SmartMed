const Store = artifacts.require("Store");

module.exports = function(deployer) {
  deployer.deploy(Store);
};
