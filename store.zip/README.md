# store

Store medical records on Ethereum Blockchain
Created using MERN stack
