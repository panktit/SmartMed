import React from "react";
import { Link } from "react-router-dom";
import { Button } from "reactstrap";
import loginImg from "../../../assets/img/login.png";

const initialState = {
  email: "",
  password: "",
  // userType: "",
};

export class Login extends React.Component {
  constructor(props) {
    super(props);
  }
  state = initialState;
  handleChange = event => {
    const isCheckbox = event.target.type === "checkbox";
    this.setState({
      [event.target.name]: isCheckbox
        ? event.target.checked
        : event.target.value
    });
  }; 

  handleSubmit = event => {
    event.preventDefault();
    const isValid = this.validate();
    console.log(this.state);
    if (isValid) {
      this.setState(initialState);
      // save the entry in database
      if(this.state.userType === "doctor") {
        bcrypt.hash(this.state.password, 10, function(err, hash) {
          axios.post('/api/doctor', { first_name: this.state.first_name, 
                                      last_name: this.state.last_name, 
                                      email: this.state.email, 
                                      password: hash, 
                                      qualification: this.state.qualification, 
                                      specialization: this.state.specialization, 
                                      license: this.state.license })
          .then((result) => {
            console.log(result);
            this.props.history.push("/index")
          });
        });
        
      } else if(this.state.userType == "patient") {
        const { first_name, last_name, email, password, age, blood_group} = this.state;
        console.log({ first_name, last_name, email, password,age, blood_group });
        axios.post('/api/patient', {  first_name, 
                                      last_name, 
                                      email, 
                                      password, 
                                      age, 
                                      blood_group })
        .then((result) => {
          console.log(result);
          history.push("/index")
        });
      }
    }
  };

  render() {
    return (
      <form onSubmit={this.handleSubmit} >
      <div className="base-container">
        <div className="header">Welcome Back!</div>
        <div className="content">
          <div className="image">
            <img src={loginImg} />
          </div>
          <div className="form">
            <div className="form-group">
                <input type="text" name="email" placeholder="Email" value={this.state.email} onChange={this.handleChange} />
            </div>
            <div className="form-group">
                <input type="password" name="password" placeholder="Password" value={this.state.password} onChange={this.handleChange} />
            </div>
          </div>
        </div>
        <div className="footer">
        <Button
          className="submit-btn"
          color="info"
        >
          Login
        </Button><br/><br/>
        <p>New to SmartMed? <Link to="/register">Register</Link></p>
        </div>
      </div>
      </form>
    );
  }
}