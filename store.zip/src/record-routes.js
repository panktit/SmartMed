import TableList from "./views/profile-sections/TableList.jsx";

var recordRoutes = [
  {
    path: "/view",
    name: "Records",
    component: TableList,
    layout: "/record"
  }
  ];
export default recordRoutes;