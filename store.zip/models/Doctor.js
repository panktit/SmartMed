var mongoose = require('mongoose');

var DoctorSchema = new mongoose.Schema({
  account: String,
  first_name: String,
  last_name: String,
  email: String,
  password: String,
  qualification: String,
  specialization: String,
  license: Number,
  updated_date: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Doctor', DoctorSchema);